# -*- coding: utf-8 -*-
import xbmcgui

from resources.lib.urepo import URepoDialog


###################################
# Main of the Recap Service
###################################
if __name__ == '__main__':
    URepoDialog.showURepoDialog('script.ebooks')
