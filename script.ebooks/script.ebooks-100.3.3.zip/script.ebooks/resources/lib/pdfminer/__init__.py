#!/usr/bin/env python
# https://github.com/euske/pdfminer
__version__ = '20140328'

if __name__ == '__main__':
    print (__version__)
